sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.doc.project1.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  