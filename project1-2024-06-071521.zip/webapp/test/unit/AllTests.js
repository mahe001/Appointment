sap.ui.define([
	"comdoc/project1/test/unit/controller/Appointment.controller"
], function () {
	"use strict";
});
